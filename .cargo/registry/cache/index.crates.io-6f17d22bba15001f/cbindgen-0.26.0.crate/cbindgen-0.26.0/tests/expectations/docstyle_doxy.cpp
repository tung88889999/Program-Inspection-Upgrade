#include <cstdarg>
#include <cstdint>
#include <cstdlib>
#include <ostream>
#include <new>

extern "C" {

/**
 * The root of all evil.
 */
void root();

} // extern "C"
