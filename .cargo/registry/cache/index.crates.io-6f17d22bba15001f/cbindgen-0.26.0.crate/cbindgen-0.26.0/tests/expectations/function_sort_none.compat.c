#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

void C(void);

void B(void);

void D(void);

void A(void);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus
