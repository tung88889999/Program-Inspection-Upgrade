#ifndef INCLUDE_GUARD_H
#define INCLUDE_GUARD_H

void root(void);

#endif /* INCLUDE_GUARD_H */
