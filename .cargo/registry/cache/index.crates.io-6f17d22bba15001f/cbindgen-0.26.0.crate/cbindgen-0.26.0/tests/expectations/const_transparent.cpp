#include <cstdarg>
#include <cstdint>
#include <cstdlib>
#include <ostream>
#include <new>

using Transparent = uint8_t;

constexpr static const Transparent FOO = 0;
