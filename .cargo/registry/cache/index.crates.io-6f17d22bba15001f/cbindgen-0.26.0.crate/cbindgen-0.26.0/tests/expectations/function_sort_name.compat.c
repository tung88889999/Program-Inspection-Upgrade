#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

void A(void);

void B(void);

void C(void);

void D(void);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus
