#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

void A(void);

void B(void);

void C(void);

void D(void);
