#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

void unnamed(const uint64_t*);

void pointer_test(const uint64_t *a);

void print_from_rust(void);
