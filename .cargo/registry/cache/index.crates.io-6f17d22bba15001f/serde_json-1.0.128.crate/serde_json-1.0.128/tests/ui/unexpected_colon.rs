use serde_json::json;

fn main() {
    json!({ : true });
}
