#ifdef __clang__
#pragma message "clang"
#endif

#ifdef __GNUC__
#pragma message "gcc"
#endif
