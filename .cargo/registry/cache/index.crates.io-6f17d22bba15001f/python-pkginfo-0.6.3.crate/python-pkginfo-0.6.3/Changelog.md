# Changelog

## 0.6.3

- Disable `bzip2` and `time` feature of the `zip` crate by default. `bzip2` support was already behind a feature, and `time` was unused.
